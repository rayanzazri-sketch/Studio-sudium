package com.exampletest.mobilestudiotest.ui

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Typeface
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast
import com.exampletest.mobilestudiotest.core.AutoSave
import com.exampletest.mobilestudiotest.core.CrashLog
import com.exampletest.mobilestudiotest.core.ProjectBackups
import com.exampletest.mobilestudiotest.core.Studio
import java.text.DateFormat
import java.util.Date

/** Crash recovery, local version history and the error log (File menu). */
object RecoveryUi {
    private fun fmtTime(t: Long) = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(t))
    private fun fmtSize(b: Long) = if (b >= 1 shl 20) "%.1f MB".format(b / 1048576f) else "${(b + 1023) / 1024} KB"
    private fun kindLabel(k: String) = when (k) {
        ProjectBackups.KIND_AUTO -> "Autosave checkpoint"
        ProjectBackups.KIND_MANUAL -> "Saved version"
        ProjectBackups.KIND_PRE_RESTORE -> "Before a restore"
        else -> k
    }

    /** At startup: if the last session closed with unsaved work, offer to bring it back. */
    fun offerRecovery(act: Activity, studio: Studio, onRestored: () -> Unit) {
        if (!AutoSave.recoveryPending) return
        val info = ProjectBackups.recoveryInfo(act)
        if (info == null) { AutoSave.resolveRecovery(); return }
        Dialogs.themed(act).setTitle("Recover unsaved work?")
            .setMessage("“${info.name}” had unsaved changes when Mobile Studio last closed. An autosaved copy from ${fmtTime(info.time)} (${fmtSize(info.bytes)}) is available.\n\n" +
                "“Keep in history” puts it in Local Backups so you can restore it later.")
            .setCancelable(false)
            .setPositiveButton("Recover") { _, _ ->
                Thread {
                    val bytes = ProjectBackups.readRecovery(act)
                    act.runOnUiThread {
                        if (bytes == null) { AutoSave.resolveRecovery(); studio.toast("The recovery copy is gone"); return@runOnUiThread }
                        AutoSave.restore(bytes, info.name) { ok, msg ->
                            AutoSave.resolveRecovery()
                            studio.toast(msg)
                            if (ok) onRestored()
                        }
                    }
                }.start()
            }
            .setNegativeButton("Keep in history") { _, _ ->
                Thread {
                    try {
                        ProjectBackups.readRecovery(act)?.let { ProjectBackups.addVersion(act, ProjectBackups.KIND_MANUAL, info.name, it, com.exampletest.mobilestudiotest.core.Settings.versionKeep) }
                        ProjectBackups.clearRecovery(act)
                    } catch (e: Exception) { CrashLog.log(act, "Couldn't move the recovery copy into history", e) }
                    act.runOnUiThread { AutoSave.resolveRecovery(); studio.toast("Kept in Local Backups") }
                }.start()
            }
            .show()
    }

    /** File → Local Backups & Version History. */
    fun versionHistory(act: Activity, studio: Studio, onRestored: () -> Unit) {
        val list = ProjectBackups.versions(act)
        val rec = ProjectBackups.recoveryInfo(act)
        val labels = ArrayList<String>()
        for (v in list) labels.add("${fmtTime(v.time)}\n${kindLabel(v.kind)} · ${v.name} · ${fmtSize(v.bytes)}")
        val b = Dialogs.themed(act).setTitle("Local Backups")
        if (labels.isEmpty()) {
            b.setMessage("No versions yet. Autosave checkpoints appear here while you work (File → Studio Settings → Autosave & Backups), or tap “Save version now”.")
        } else {
            b.setItems(labels.toTypedArray()) { _, i -> versionActions(act, studio, list[i], onRestored) }
        }
        b.setNeutralButton("Save version now") { _, _ ->
            AutoSave.saveVersionNow { ok, msg -> Toast.makeText(act, msg, Toast.LENGTH_SHORT).show() }
        }
        b.setPositiveButton("Close", null)
        val used = ProjectBackups.totalBytes(act)
        b.setNegativeButton("Storage: ${fmtSize(used)}${if (rec != null) " (+ recovery copy)" else ""}", null)
        b.show()
    }

    private fun versionActions(act: Activity, studio: Studio, v: ProjectBackups.Version, onRestored: () -> Unit) {
        Dialogs.themed(act).setTitle("${fmtTime(v.time)} · ${v.name}")
            .setMessage("${kindLabel(v.kind)}, ${fmtSize(v.bytes)}.\n\nRestoring replaces the open place; your current state is first kept as a “Before a restore” version.")
            .setPositiveButton("Restore") { _, _ ->
                Thread {
                    val bytes = try { v.file.readBytes() } catch (_: Exception) { null }
                    act.runOnUiThread {
                        if (bytes == null) { studio.toast("Couldn't read that version"); return@runOnUiThread }
                        AutoSave.restore(bytes, v.name) { ok, msg -> studio.toast(msg); if (ok) onRestored() }
                    }
                }.start()
            }
            .setNeutralButton("Delete") { _, _ -> ProjectBackups.delete(v); studio.toast("Version deleted") }
            .setNegativeButton("Cancel", null)
            .show()
    }

    /** File → Error Log. */
    fun errorLog(act: Activity) {
        val text = CrashLog.read(act).ifEmpty { "No errors logged." }
        val tv = Ui.text(act, text, 11f, Ui.TEXT).apply {
            typeface = Typeface.MONOSPACE
            setTextIsSelectable(true)
            isSingleLine = false
            setPadding(Ui.dp(act, 14f), Ui.dp(act, 8f), Ui.dp(act, 14f), Ui.dp(act, 8f))
        }
        val sv = ScrollView(act).apply { addView(tv) }
        val box = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; addView(sv, Ui.lp(Ui.MATCH, Ui.dp(act, 380f))) }
        Dialogs.themed(act).setTitle("Error Log").setView(box)
            .setPositiveButton("Close", null)
            .setNeutralButton("Copy") { _, _ ->
                (act.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("Mobile Studio error log", text))
                Toast.makeText(act, "Copied", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Clear") { _, _ -> CrashLog.clear(act); Toast.makeText(act, "Log cleared", Toast.LENGTH_SHORT).show() }
            .show()
    }
}
