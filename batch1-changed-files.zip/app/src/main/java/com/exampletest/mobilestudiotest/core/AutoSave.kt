package com.exampletest.mobilestudiotest.core

import android.content.Context
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Autosave and crash recovery. While the place has unsaved changes, a copy is written to private
 * storage on a background thread every [Settings.autosaveSeconds] seconds (and when the app goes to
 * the background), so the editor never waits on it. If the app is killed or crashes before you save,
 * the copy is offered back the next time Mobile Studio starts. Saving the place removes the copy.
 *
 * Big places take longer to serialize, so the interval backs off automatically when a pass is slow.
 */
object AutoSave : Studio.Listener {
    private var app: Context? = null
    private var studio: Studio? = null
    private val io = Executors.newSingleThreadExecutor { r -> Thread(r, "autosave").apply { isDaemon = true; priority = Thread.MIN_PRIORITY } }
    private val busy = AtomicBoolean(false)
    @Volatile private var changed = false
    @Volatile private var disabledForSession = false
    private var slowFactor = 1
    private var lastVersionAt = 0L
    private var warnedSlow = false
    /** A recovery copy from the last session is waiting for the user's decision: don't touch it meanwhile. */
    @Volatile var recoveryPending = false; private set

    fun resolveRecovery() { recoveryPending = false }

    /** Milliseconds the last successful pass took (shown in the Performance info). */
    @Volatile var lastDurationMs = 0L; private set
    @Volatile var lastSavedAt = 0L; private set

    private val tick = object : Runnable {
        override fun run() {
            val s = studio ?: return
            try { saveIfNeeded(false) } catch (e: Throwable) { app?.let { CrashLog.log(it, "Autosave tick failed", e) } }
            s.main.postDelayed(this, intervalMs())
        }
    }

    private fun intervalMs(): Long = (Settings.autosaveSeconds.coerceIn(15, 600) * 1000L * slowFactor).coerceAtMost(15 * 60_000L)

    /** Call once per process (MainActivity does, on first launch). */
    fun start(ctx: Context, s: Studio) {
        if (studio != null) return
        app = ctx.applicationContext
        studio = s
        recoveryPending = try { ProjectBackups.recoveryInfo(app!!) != null } catch (_: Exception) { false }
        s.listeners.add(this)
        s.main.postDelayed(tick, intervalMs())
    }

    // Studio.Listener -----------------------------------------------------------------
    override fun onTreeChanged() { if (studio?.isPlaying == false) changed = true }
    override fun onPropsChanged() { if (studio?.isPlaying == false) changed = true }
    override fun onModelReplaced() { changed = studio?.dirty == true }
    override fun onDirtyChanged() {
        val s = studio ?: return
        if (s.dirty) changed = true
        else {
            // Saved (or a fresh place): nothing to recover any more.
            changed = false
            if (recoveryPending) return
            val a = app ?: return
            io.execute { try { ProjectBackups.clearRecovery(a) } catch (_: Exception) {} }
        }
    }

    /** Writes the recovery copy now if there are unsaved changes (the tick, and onPause). */
    fun saveIfNeeded(force: Boolean) {
        val s = studio ?: return
        val a = app ?: return
        if (disabledForSession || !Settings.autosave || recoveryPending) return
        if (!s.dirty || s.isPlaying) return
        if (!changed && !force) return
        if (!busy.compareAndSet(false, true)) return
        changed = false
        val name = s.fileName
        io.execute {
            val t0 = System.currentTimeMillis()
            try {
                val bytes = s.serializePlace()
                ProjectBackups.writeRecovery(a, name, bytes)
                val now = System.currentTimeMillis()
                lastSavedAt = now
                lastDurationMs = now - t0
                if (now - lastVersionAt >= Settings.versionMinutes.coerceIn(1, 120) * 60_000L) {
                    ProjectBackups.addVersion(a, ProjectBackups.KIND_AUTO, name, bytes, Settings.versionKeep)
                    lastVersionAt = now
                }
                // Large places: don't hammer the CPU and storage; back off up to 4x.
                if (lastDurationMs > 2000) {
                    if (slowFactor < 4) slowFactor++
                    if (!warnedSlow) { warnedSlow = true; OutputLog.warn("Autosave took ${lastDurationMs / 1000f}s (large place); autosaving less often.") }
                } else if (slowFactor > 1 && lastDurationMs < 800) slowFactor--
            } catch (e: OutOfMemoryError) {
                disabledForSession = true
                CrashLog.log(a, "Autosave ran out of memory; autosave turned off for this session", e)
                OutputLog.error("Autosave turned off for this session: not enough memory. Save your place manually.")
            } catch (e: Exception) {
                changed = true // try again next time
                CrashLog.log(a, "Autosave failed", e)
                OutputLog.warn("Autosave failed: ${e.message}")
            } finally {
                busy.set(false)
            }
        }
    }

    /** Used by the crash handler: tries to write the recovery copy, waiting at most ~2.5 seconds. */
    fun emergencySave() {
        val s = studio ?: return
        val a = app ?: return
        if (!s.dirty || disabledForSession || !Settings.autosave || recoveryPending) return
        val name = s.fileName
        val t = Thread {
            try { ProjectBackups.writeRecovery(a, name, s.serializePlace()) } catch (_: Throwable) {}
        }
        t.isDaemon = true
        t.start()
        try { t.join(2500) } catch (_: InterruptedException) {}
    }

    /** Takes a version now (the "Save version now" button). Runs [done] on the main thread. */
    fun saveVersionNow(done: (Boolean, String) -> Unit) {
        val s = studio ?: return done(false, "Not ready")
        val a = app ?: return done(false, "Not ready")
        val name = s.fileName
        io.execute {
            val result = try {
                val bytes = s.serializePlace()
                ProjectBackups.addVersion(a, ProjectBackups.KIND_MANUAL, name, bytes, Settings.versionKeep)
                true to "Version saved"
            } catch (e: Throwable) {
                CrashLog.log(a, "Manual version failed", e)
                false to (e.message ?: "Couldn't save a version")
            }
            s.main.post { done(result.first, result.second) }
        }
    }

    /** Restores a version or the recovery copy. The current state is kept as a "before restore" version first. */
    fun restore(bytes: ByteArray, name: String, done: (Boolean, String) -> Unit) {
        val s = studio ?: return done(false, "Not ready")
        val a = app ?: return done(false, "Not ready")
        io.execute {
            var err: String? = null
            try {
                if (s.dirty || s.editModel.children.isNotEmpty()) {
                    try { ProjectBackups.addVersion(a, ProjectBackups.KIND_PRE_RESTORE, s.fileName, s.serializePlace(), Settings.versionKeep) }
                    catch (e: Exception) { CrashLog.log(a, "Couldn't keep a copy before restoring", e) }
                }
            } catch (_: Throwable) {}
            s.main.post {
                try {
                    s.restoreSnapshot(bytes)
                    s.fileName = name
                    changed = true
                    done(true, "Restored “$name”")
                } catch (e: Throwable) {
                    CrashLog.log(a, "Restore failed", e)
                    err = e.message ?: e.javaClass.simpleName
                    done(false, "Couldn't restore: $err")
                }
            }
        }
    }

}
