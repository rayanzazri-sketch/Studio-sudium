package com.exampletest.mobilestudiotest.core

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

/**
 * On-device safety copies of the open place (private app storage, never uploaded):
 *  - the recovery copy: the latest autosave of a place that has unsaved changes. It is removed
 *    as soon as the place is saved, so if it exists at startup the app closed with unsaved work.
 *  - version history: checkpoints you can restore (autosave checkpoints, manual versions, and a
 *    copy of the current state that is taken just before any restore).
 * Every write goes to a temporary file first and is renamed into place, so a crash or a full
 * disk never leaves a half-written copy behind.
 */
object ProjectBackups {
    const val KIND_AUTO = "auto"
    const val KIND_MANUAL = "manual"
    const val KIND_PRE_RESTORE = "prerestore"

    class Version(val file: File, val time: Long, val kind: String, val name: String) {
        val bytes: Long get() = file.length()
    }

    class RecoveryInfo(val name: String, val time: Long, val bytes: Long)

    private fun dir(ctx: Context, sub: String) = File(File(ctx.applicationContext.filesDir, "backups"), sub).apply { mkdirs() }
    private fun recoveryFile(ctx: Context) = File(dir(ctx, "recovery"), "current.rbxl")
    private fun recoveryMeta(ctx: Context) = File(dir(ctx, "recovery"), "current.json")

    // ------------------------------------------------------------------ safe writing

    /** Writes [bytes] to [dest] through a temp file + rename. Throws IOException when the disk is full. */
    fun atomicWrite(dest: File, bytes: ByteArray) {
        val parent = dest.parentFile ?: throw IOException("No folder for ${dest.path}")
        parent.mkdirs()
        if (parent.usableSpace < bytes.size.toLong() * 2 + 8L * 1024 * 1024) throw IOException("Not enough free storage for a safety copy")
        val tmp = File(parent, dest.name + ".tmp")
        try {
            FileOutputStream(tmp).use { out -> out.write(bytes); out.flush(); out.fd.sync() }
            if (!tmp.renameTo(dest)) {
                dest.delete()
                if (!tmp.renameTo(dest)) throw IOException("Couldn't move ${tmp.name} into place")
            }
        } finally {
            if (tmp.exists()) tmp.delete()
        }
    }

    // ------------------------------------------------------------------ recovery copy

    fun writeRecovery(ctx: Context, name: String, bytes: ByteArray) {
        atomicWrite(recoveryFile(ctx), bytes)
        atomicWrite(recoveryMeta(ctx), JSONObject().put("name", name).put("time", System.currentTimeMillis()).toString().toByteArray())
    }

    fun recoveryInfo(ctx: Context): RecoveryInfo? {
        val f = recoveryFile(ctx)
        if (!f.exists() || f.length() == 0L) return null
        return try {
            val m = JSONObject(recoveryMeta(ctx).readText())
            RecoveryInfo(m.optString("name", "Place1.rbxl"), m.optLong("time", f.lastModified()), f.length())
        } catch (_: Exception) { RecoveryInfo("Place1.rbxl", f.lastModified(), f.length()) }
    }

    fun readRecovery(ctx: Context): ByteArray? = recoveryFile(ctx).takeIf { it.exists() }?.readBytes()

    fun clearRecovery(ctx: Context) {
        recoveryFile(ctx).delete()
        recoveryMeta(ctx).delete()
    }

    // ------------------------------------------------------------------ version history

    private fun safeName(name: String) = name.replace(Regex("[^A-Za-z0-9.-]"), "-").take(60).ifEmpty { "place" }

    fun addVersion(ctx: Context, kind: String, name: String, bytes: ByteArray, keepAuto: Int): Version {
        val time = System.currentTimeMillis()
        val f = File(dir(ctx, "versions"), "${time}_${kind}_${safeName(name)}.rbxl")
        atomicWrite(f, bytes)
        prune(ctx, keepAuto)
        return Version(f, time, kind, name)
    }

    /** Newest first. */
    fun versions(ctx: Context): List<Version> =
        (dir(ctx, "versions").listFiles { f -> f.isFile && f.name.endsWith(".rbxl") } ?: emptyArray())
            .mapNotNull { parse(it) }.sortedByDescending { it.time }

    private fun parse(f: File): Version? {
        val parts = f.name.removeSuffix(".rbxl").split("_", limit = 3)
        if (parts.size < 3) return null
        val t = parts[0].toLongOrNull() ?: return null
        return Version(f, t, parts[1], parts[2])
    }

    fun delete(v: Version) { v.file.delete() }

    private fun prune(ctx: Context, keepAuto: Int) {
        for (v in toPrune(versions(ctx).map { it.kind to it.time }, keepAuto.coerceAtLeast(1), MAX_OTHER)) {
            versions(ctx).firstOrNull { it.kind == v.first && it.time == v.second }?.let { delete(it) }
        }
    }

    private const val MAX_OTHER = 30

    /**
     * Which (kind, time) entries to delete: keeps the newest [keepAuto] autosave checkpoints and the
     * newest [keepOther] manual / pre-restore versions. [all] is newest first.
     */
    fun toPrune(all: List<Pair<String, Long>>, keepAuto: Int, keepOther: Int): List<Pair<String, Long>> {
        val (auto, other) = all.partition { it.first == KIND_AUTO }
        return auto.drop(keepAuto) + other.drop(keepOther)
    }

    fun totalBytes(ctx: Context): Long =
        versions(ctx).sumOf { it.bytes } + (recoveryFile(ctx).takeIf { it.exists() }?.length() ?: 0L)
}
