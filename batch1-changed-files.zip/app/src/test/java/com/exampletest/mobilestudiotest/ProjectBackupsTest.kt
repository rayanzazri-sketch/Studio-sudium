package com.exampletest.mobilestudiotest

import com.exampletest.mobilestudiotest.core.ProjectBackups
import org.junit.Assert.*
import org.junit.Test
import java.io.File

/** Pure-JVM checks for the safety-copy logic (no Android needed). */
class ProjectBackupsTest {
    @Test fun pruneKeepsNewestAutoAndOthersSeparately() {
        // newest first
        val all = listOf(
            "auto" to 100L, "manual" to 90L, "auto" to 80L, "auto" to 70L, "prerestore" to 60L, "auto" to 50L,
        )
        val del = ProjectBackups.toPrune(all, keepAuto = 2, keepOther = 1)
        assertEquals(setOf("auto" to 70L, "auto" to 50L, "prerestore" to 60L), del.toSet())
    }

    @Test fun pruneDeletesNothingWhenUnderLimits() {
        val all = listOf("auto" to 3L, "manual" to 2L, "auto" to 1L)
        assertTrue(ProjectBackups.toPrune(all, 12, 30).isEmpty())
    }

    @Test fun atomicWriteReplacesFileAndLeavesNoTempFile() {
        val dir = createTempDir("backup-test")
        try {
            val f = File(dir, "x.rbxl")
            ProjectBackups.atomicWrite(f, byteArrayOf(1, 2, 3))
            ProjectBackups.atomicWrite(f, byteArrayOf(9, 8))
            assertArrayEquals(byteArrayOf(9, 8), f.readBytes())
            assertFalse(File(dir, "x.rbxl.tmp").exists())
        } finally { dir.deleteRecursively() }
    }
}
