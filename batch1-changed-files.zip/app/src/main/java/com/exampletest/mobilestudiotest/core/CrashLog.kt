package com.exampletest.mobilestudiotest.core

import android.content.Context
import android.os.Build
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Error log kept on the device (filesDir/logs/errors.log). Uncaught exceptions are written here
 * before the process dies, and the editor can show or share the log (File → Error Log).
 * Nothing is uploaded anywhere.
 */
object CrashLog {
    private const val MAX_BYTES = 256 * 1024L
    private val lock = Any()
    @Volatile private var installed = false

    private fun file(ctx: Context): File = File(File(ctx.applicationContext.filesDir, "logs").apply { mkdirs() }, "errors.log")

    /** Installs the uncaught-exception handler (once per process). The previous handler still runs afterwards. */
    fun install(ctx: Context) {
        if (installed) return
        installed = true
        val app = ctx.applicationContext
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try { log(app, "UNCAUGHT exception on thread \"${t.name}\"", e) } catch (_: Throwable) {}
            // Best effort: keep the user's unsaved work before the process goes away.
            try { AutoSave.emergencySave() } catch (_: Throwable) {}
            previous?.uncaughtException(t, e)
        }
    }

    fun log(ctx: Context, message: String, error: Throwable? = null) {
        synchronized(lock) {
            val f = file(ctx)
            if (f.length() > MAX_BYTES) {
                val old = File(f.parentFile, "errors.log.1")
                old.delete()
                f.renameTo(old)
            }
            val rt = Runtime.getRuntime()
            val sb = StringBuilder()
            sb.append(SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())).append("  ").append(message).append('\n')
            sb.append("  device=").append(Build.MANUFACTURER).append(' ').append(Build.MODEL)
                .append(" android=").append(Build.VERSION.SDK_INT)
                .append(" heapUsedMB=").append((rt.totalMemory() - rt.freeMemory()) shr 20)
                .append(" heapMaxMB=").append(rt.maxMemory() shr 20).append('\n')
            if (error != null) {
                val sw = StringWriter()
                error.printStackTrace(PrintWriter(sw))
                sb.append(sw.toString().prependIndent("  ")).append('\n')
            }
            f.appendText(sb.toString())
        }
    }

    /** The end of the log (newest last), at most [maxChars] characters. */
    fun read(ctx: Context, maxChars: Int = 60_000): String = synchronized(lock) {
        val f = file(ctx)
        if (!f.exists()) return ""
        val t = f.readText()
        if (t.length > maxChars) t.substring(t.length - maxChars) else t
    }

    fun clear(ctx: Context) = synchronized(lock) {
        val f = file(ctx)
        f.delete()
        File(f.parentFile, "errors.log.1").delete()
        Unit
    }
}
